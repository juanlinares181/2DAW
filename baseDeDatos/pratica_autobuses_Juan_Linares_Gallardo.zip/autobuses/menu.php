<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>BASE DE DATOS AUTOBUSES</title>
    </head>
    <body>
        <?php
        
        ?>
        <h1 align="center">AUTOCARES DE LOS MUERTOS</h1>
        <h2 align="center">MENÚ</h2>
        <form action="" method="POST" align="center"><br><br>
            1- <a href="anadirAutobus.php?op=1">Añadir Autobus</a><br><br>
            2- <a href="anadirViaje.php?op=2">Añadir Viaje</a><br><br>
            3- <a href="modificarYBorrar.php?op=3">Modificar o Borrar Viaje</a><br><br>
            4- <a href="reservar.php?op=4">Reservar Viaje</a><br><br>
        </form>
    </body> 
</html>