<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>BASE DE DATOS JUGADORES</title>
    </head>
    <body>
        <?php
        
        ?>
        <h1 align="center">MENÚ</h1>
        <form action="" method="POST" align="center"><br><br>
            1- <a href="introduccion.php?op=1">Introducción</a><br><br>
            2- <a href="mostrar.php?op=2">Mostrar</a><br><br>
            3- <a href="buscar.php?op=3">Buscar</a><br><br>
            4- <a href="modificar.php?op=4">Modificar</a><br><br>
            5- <a href="borrar.php?op=5">Borrar</a><br><br>
        </form>
    </body> 
</html>